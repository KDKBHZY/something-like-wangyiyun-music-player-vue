var app = new Vue(
    {
        el: "#player",

        data: {
            musiclist: [],
            musiclist1: [],
            music: "",
            musicurl: "",
            picurl: "",
            hotComments: [],
            avaurl: "",
            isplay: false,
            isshow: false,
            isshow1: true,

            mvurl:""
        },
        methods: {
            search: function () {
                var that = this;
                axios.get("https://autumnfish.cn/search?keywords=" + this.music).then(
                    function (response) {

                        that.musiclist1 = response.data.result.songs;
                        console.log(that.musiclist);
                    },
                    function (err) {

                    }

                )
            },
            result: function () {
                this.musiclist = this.musiclist1;
                this.musiclist1=[];
                 this.isshow1=false;
            },
            playmusic: function (musicid) {
                //console.log(musicid);
                var that = this;
                axios.get("https://autumnfish.cn/song/url?id=" + musicid).then(
                    function (response) {
                        //console.log(response.data.data[0].url);
                        that.musicurl = response.data.data[0].url;
                    },
                    function (err) {

                    })
                axios.get("https://autumnfish.cn/song/detail?ids=" + musicid).then(
                    function (response) {
                        //console.log(response.data.songs[0].al.picUrl);
                        that.picurl = response.data.songs[0].al.picUrl;

                    },
                    function (err) {

                    })

                // 歌曲评论获取
                axios.get("https://autumnfish.cn/comment/hot?type=0&id=" + musicid).then(
                    function (response) {
                        // console.log(response);
                       // console.log(response.data.hotComments);
                        that.hotComments = response.data.hotComments;
                        //that.avaurl = response.data.hotComments.user.avatarUrl;

                    },
                    function (err) { }
                );
            },
            play: function () {
                //console.log("play");
                this.isplay = true;
            },
            pause: function () {
               // console.log("pause")
                this.isplay = false;
            },
            playmv:function(mvid){
                var that = this;
                axios.get("https://autumnfish.cn/mv/url?id="+mvid).then(function(response){
                    console.log(response.data.data.url);
                    that.isshow=true;
                    that.mvurl=response.data.data.url;
                },function(err){

                })
            },
            hide:function(){
                this.isshow=false;
                this.mvurl="";
            }
        }
    })